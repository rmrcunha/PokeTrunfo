#ifndef JOGO_H
#define JOGO_H

void newGame(int numPlayers, int numCards);
void CL_BUFF();

#endif
